function smplx = get_simplex()

v1 = [0; 0; 1];
v2 = [0; 2*sqrt(2)/3; -1/3];
v3 = [sqrt(6)/3; -sqrt(2)/3; -1/3]; 
v4 = [-sqrt(6)/3; -sqrt(2)/3; -1/3]; 

smplx.V = [v1,v2,v3,v4];

% Smplx = Polyhedron('V', smplx.V');
% plot(Smplx,'color',[0.5,0.5,0.5], 'alpha',0.1, 'linestyle','-','edgecolor','black');
% hold on
% plot3([0, v1(1)], [0, v1(2)], [0, v1(3)], 'Linewidth', 3, 'Color', [0 0 0])
% plot3([0, v2(1)], [0, v2(2)], [0, v2(3)], 'Linewidth', 3, 'Color', [0 0 0])
% plot3([0, v3(1)], [0, v3(2)], [0, v3(3)], 'Linewidth', 3, 'Color', [0 0 0])
% plot3([0, v4(1)], [0, v4(2)], [0, v4(3)], 'Linewidth', 3, 'Color', [0 0 0])

box = Polyhedron('lb', -0.1*ones(3,1), 'ub', 0.1*ones(3,1));
box1 = v1+box; 
box2 = v2+box; 
box3 = v3+box; 
box4 = v4+box; 

smplx.Box = [box1;box2;box3;box4];

% plot(box1,'color',[0.5,0.5,0.5], 'alpha',1, 'linestyle','none','edgecolor','black');
% plot(box2,'color',[1,0,0], 'alpha',1, 'linestyle','none','edgecolor','black');
% plot(box3,'color',[0,1,0], 'alpha',1, 'linestyle','none','edgecolor','black');
% plot(box4,'color',[0,0,1], 'alpha',1, 'linestyle','none','edgecolor','black');
% 
% axis equal
% plot_camera_frame(camera_pos, camera_dir);



