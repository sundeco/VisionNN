function plot_arrow(x_init, x_end, end_txt, clr)
if nargin < 4
    clr = 'black';
end
if nargin < 3
    end_txt = '';
end

x1 = x_init;
x2 = x_end; 
plot3([x1(1),x2(1)], [x1(2),x2(2)], [x1(3),x2(3)], 'Linewidth', 1,'Color',clr);
hold on; 
a = blkdiag([cos(pi/6), -sin(pi/6); sin(pi/6), cos(pi/6)], 1)*(x1-x2)*0.3; 
b = blkdiag([cos(-pi/6), -sin(-pi/6); sin(-pi/6), cos(-pi/6)], 1)*(x1-x2)*0.3; 
plot3([x2(1),x2(1)+a(1)], [x2(2),x2(2)+a(2)], [x2(3),x2(3)+a(3)], 'Linewidth', 1,'Color',clr);
plot3([x2(1),x2(1)+b(1)], [x2(2),x2(2)+b(2)], [x2(3),x2(3)+b(3)], 'Linewidth', 1,'Color',clr);
text(x2(1)-0.01,x2(2)-0.01, x2(3)-0.01, end_txt,'Interpreter','latex');