total = [];
for iter = 1:500
clearvars -except total
load model2NN3.mat
n = 8;

%take some random data point from the neural network and convert it into
%optimal solution for reverse engineering
[~, maxsize] = size(dataMat);
index = floor(maxsize*rand)+1;
ximarray = dataMat(1:8, index);
yimarray = dataMat(9:16, index);
prediction = predict(net, dataMat(:,index)');
prediction = prediction';
c = prediction(1:3); 
w = prediction(4); l = prediction(5); h = 1;
v1 = [-w/2; -l/2; h/2] + c;
v2 = [w/2; -l/2; h/2] + c;
v3 = [w/2; -l/2; -h/2] + c;
v4 = [-w/2; -l/2; -h/2] + c;
v5 = [-w/2; l/2; h/2] + c;
v6 = [w/2; l/2; h/2] + c;
v7 = [w/2; l/2; -h/2] + c;
v8 = [-w/2; l/2; -h/2] + c;
opt = [v1; v2; v3; v4; v5; v6; v7; v8; c; w; l; h];
opt = double(opt);

%reverse engineering: alpha/beta not known
%desired = [alpha0 alpha1 beta0 beta1];
alpha0 = sdpvar(1); alpha1 = sdpvar(1);
beta0 = sdpvar(1); beta1 = sdpvar(1);
v = sdpvar(2*n+1, 1);
lambda = sdpvar(2,1);
constraints = [];

%QP formulation of optimization problem 
Q = getQmodel2();

G = zeros(2,30);
G(1,28) = -1; G(2,29) = -1;
h = [0; 0];

A = [];
for i = 1:n
    xim = ximarray(i);
    yim = yimarray(i);
    A = blkdiag(A, [alpha1 0 alpha0-xim; 0 beta1 beta0-yim]);
end
A = [A zeros(2*n, 6)];
A = [A; zeros(1,29) 1];
b = zeros(2*n, 1);
b = [b; 1];

kkt1 = Q*opt + A'*v + G'*lambda;
kkt2 = A*opt - b;
kkt3 = diag(lambda)*(G*opt-h);
constraints = [lambda >= 0];
objective = norm(kkt1, inf) + norm(kkt2, inf) + norm(kkt3, inf);

options = sdpsettings('verbose', 1, 'solver', 'gurobi');
options.gurobi.presolve = 0;
ans = optimize(constraints, objective, options)
%disp(desired)
tmp = [value(alpha0) value(alpha1) value(beta0) value(beta1)]
total = [total; tmp];
end