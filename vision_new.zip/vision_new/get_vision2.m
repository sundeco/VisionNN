function img = get_vision2(camera_pos, camera_dir, offset, w, l, h, r)
    negsxf = -0.3;
    negsyf = -0.5;
    sox = 0.4; soy = 0.2;

    prism = get_prism(offset,w,l,h);
    h = figure; 
    h.Position = [100 100 400 400];
    set(gca,'position',[0 0 1 1],'units','normalized')

    hold on
    dome = Polyhedron('lb',[-10, -10],'ub', [10, 10]);
    plot(dome,'color',[1,1,1], 'alpha',1, 'linestyle','none','edgecolor','black');

    img_Box = [];

    for i = 1:1:8
        %find analog coordinates of each prism box vertices 
        m = [];
        for j = 1:8
            Xcvec = camera_dir*prism.Box(i).V(j,:)' + [0; 0; r];
            rvec = Xcvec/Xcvec(3);
            xim = (rvec(1)-sox)/negsxf;
            yim = (rvec(2)-soy)/negsyf;
            m = [m [xim; yim]];
        end
        %m = world_2_analog(prism.Box(i).V', camera_pos, camera_dir);
        img_Box = [img_Box, Polyhedron('V', m(1:2,:)');];
        % l = world_2_analog([[0;0;0],smplx.V(:,i)], camera_pos, camera_dir);
    end
    
    M = zeros(8);
    M(1,2) = 1; M(2,3) = 1; M(3,4) = 1; M(1,4) = 1;
    M(5,6) = 1; M(6,7) = 1; M(7,8) = 1; M(5,8) = 1;
    M(1,5) = 1; M(2,6) = 1; M(3,7) = 1; M(4,8) = 1;
    
    for i = 1:8
        for j = 1:8
            if M(i,j) == 1
                %convert prism.V into 2D image coordinates 
                Xcvec = camera_dir*prism.V(:,i) + [0; 0; r];
                rvec = Xcvec/Xcvec(3);
                xim = (rvec(1)-sox)/negsxf;
                yim = (rvec(2)-soy)/negsyf;
                Xcvec = camera_dir*prism.V(:,j) + [0; 0; r];
                rvec = Xcvec/Xcvec(3);
                xim2 = (rvec(1)-sox)/negsxf;
                yim2 = (rvec(2)-soy)/negsyf;
                e = [xim xim2; yim yim2];
                %e = world_2_analog([prism.V(:,i),prism.V(:,j)], camera_pos, camera_dir);
                plot(e(1,:), e(2,:), 'Linewidth', 3, 'Color', [0 0 0]); 
            end
        end
    end
    
    plot(img_Box(1),'color',[0.9100 0.4100 0.1700], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(2),'color',[1,0,0], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(3),'color',[0,1,0], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(4),'color',[0,0,1], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(5),'color',[0.2, 0.5, 0.8], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(6),'color',[0.6, 0.7, 0.4], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(7),'color',[0.9, 0.2, 0.4], 'alpha',1, 'linestyle','none','edgecolor','black');
    plot(img_Box(8),'color',[0.7, 0.9, 0.5], 'alpha',1, 'linestyle','none','edgecolor','black');
    
    axis([0,3,0,3])
    grid on
    axis on
    axis square

    % pause;
    F = getframe(gcf);
    [img, ~] = frame2im(F);
    img = imresize(img, 0.1);

    close(h)
end