clear,clc

% we know: ||camera_pos||_2 = 3 in the world coordinate system
r = 3;
N = 20;

% a tetrahedron centered at the origin of the world
% we know its corners' world-coordinates
smplx = get_simplex(); 
xi = smplx.V; 

pp = [];
qq = [];
for theta = 0:pi/N:2*pi
    camera_pos = [r*cos(theta); r*sin(theta); 0]; % p
    camera_dir = pos_2_dir(camera_pos); % R(p)
    
    img = get_vision(camera_pos, camera_dir);
    pixls = get_corner_pixl(img); 
    eta = pixl_2_analog(pixls);
    est_pos = estimate_pos(eta, xi, r, 1); 
    
    norm(est_pos-camera_pos,2)
    
    qq = [qq, camera_pos];
    pp = [pp, est_pos];
    % imshow(img)
    % eta = world_2_analog(xi, camera_pos, camera_dir);
    % est_pos = estimate_pos(eta, xi, r); 
end

plot(1:2*N+1, pp(1,:))
hold on
plot(1:2*N+1, qq(1,:))
