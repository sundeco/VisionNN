bruh = [dataMatrix centers];
i = 1;
while 1==1
    [dataPoints, ~] = size(bruh);
    if i > dataPoints
        break
    end
    if sum(isnan(bruh(i,:))) ~= 0
        bruh(i,:) = [];
        i = i-1;
    end
    i = i+1;
end

dataMat = bruh(:,1:16);
centerMat = bruh(:, 17:19);

layers = [
    featureInputLayer(16,'Name','input')
     fullyConnectedLayer(16, 'Name', 'fc16')
     leakyReluLayer
     fullyConnectedLayer(10, 'Name', 'fc10')
     leakyReluLayer
    fullyConnectedLayer(3, 'Name', 'fc')
    regressionLayer]
options = trainingOptions('sgdm', ...
    'MaxEpochs', 1000, ...
    'InitialLearnRate',0.01, ...
    'Verbose',false, ...
    'Plots','training-progress');
[net, info] = trainNetwork(dataMat, centerMat, layers, options)