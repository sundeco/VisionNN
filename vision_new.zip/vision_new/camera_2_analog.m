function eta = camera_2_analog(zeta)
% zeta: Mc
% eta: m

camera = get_camera_const();

f = camera.f;
cu = camera.cu; % analogue
cv = camera.cv; 
ku = camera.ku;
kv = camera.kv;

gamma = camera.gamma;

K = [ku*f, gamma, cu; 
     0,    kv*f,  cv;
     0,    0,     1];

z = zeta(3);
eta = (1/z)*K*zeta; 


