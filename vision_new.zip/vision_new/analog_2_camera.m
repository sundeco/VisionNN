function zeta_hat = analog_2_camera(eta)

camera = get_camera_const();

f = camera.f;
cu = camera.cu; % analogue
cv = camera.cv; 
ku = camera.ku;
kv = camera.kv;

gamma = camera.gamma;

K_22 = [ku*f, gamma; 
        0,    kv*f];
 
zeta_hat = [];
for i = 1:1:size(eta,2)
    zeta_hat = [zeta_hat, [K_22\(eta(1:2,i)-[cu;cv]);1]]; 
end


