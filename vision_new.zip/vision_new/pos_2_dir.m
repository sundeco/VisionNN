function dir = pos_2_dir(pos)
% assume: look from pos to the origin (world)
%         dir1 is horizontal

% x = pos(1);
% y = pos(2);
% z = pos(3); 
% 
% if abs(x) <= 1e-15 && abs(y) <= 1e-15
%     if z > 0
%         dir = [[1;0;0],[0; -1; 0],[0; 0; -1]]; 
%     else
%         dir = [[1;0;0],[0; 1; 0],[0; 0; 1]]; 
%     end
%     return
% end
% dir1 = [-y;x;0]/norm([x;y],2);
% dir3 = [-x;-y;-z]/norm(pos,2); 
% dir2 = null([dir1'; dir3']); 
% if dir2(3) > 0
%     dir2 = -dir2;
% end
% 
% dir = [dir1, dir2, dir3]; 

p1 = pos(1);
p2 = pos(2);
r = sqrt(p1^2+p2^2);
dir = [-p2/r p1/r 0; 0 0 -1; -p1/r -p2/r 0];
dir = [-p2/r p1/r 0; -p1/r -p2/r 0; 0 0 -1];