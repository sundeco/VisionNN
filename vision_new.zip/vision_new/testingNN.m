alpha0 = rand; alpha1 = rand;
beta0 = rand; beta1 = rand;
dataPoints = 5000;
dataMat = []; centerMat = [];

for j = 1:dataPoints
    tobreak = false;
    c = rand(3,1); %center of prism
    w = rand; h = 1; l = rand;
    v1 = [-w/2; -l/2; h/2] + c;
    v2 = [w/2; -l/2; h/2] + c;
    v3 = [w/2; -l/2; -h/2] + c;
    v4 = [-w/2; -l/2; -h/2] + c;
    v5 = [-w/2; l/2; h/2] + c;
    v6 = [w/2; l/2; h/2] + c;
    v7 = [w/2; l/2; -h/2] + c;
    v8 = [-w/2; l/2; -h/2] + c;
    V = [v1 v2 v3 v4 v5 v6 v7 v8];

    ximarray = []; yimarray = [];
    for i = 1:8
        Xi = V(1,i); Yi = V(2,i); Zi = V(3,i);
        ximarray = [ximarray; (alpha1*Xi + alpha0*Zi)/Zi];
        yimarray = [yimarray; (beta1*Yi + beta0*Zi)/Zi];
        if max(abs(ximarray)) + max(abs(yimarray)) > 10
            tobreak = true;
        end
    end
    
    if tobreak
        continue;
    end

    input = [ximarray; yimarray];
    output = [c; w; l];
    dataMat = [dataMat input];
    centerMat = [centerMat output];
end

layers = [
    featureInputLayer(16,'Name','input')
     fullyConnectedLayer(16, 'Name', 'fc16')
     leakyReluLayer
     fullyConnectedLayer(10, 'Name', 'fc10')
     leakyReluLayer
    fullyConnectedLayer(5, 'Name', 'fc')
    regressionLayer]
options = trainingOptions('sgdm', ...
    'MaxEpochs', 5000, ...
    'InitialLearnRate',0.001, ...
    'Verbose',false, ...
    'Plots','training-progress');
[net, info] = trainNetwork(dataMat', centerMat', layers, options)