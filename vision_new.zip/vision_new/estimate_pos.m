function pos = estimate_pos(eta, xi, r, type)
    if type == 1
        zeta_hat = analog_2_camera(eta);
        n = size(zeta_hat,2);
        ni = zeta_hat;
        T = [0; 0; r];
        ei = xi;
        p1 = sdpvar(1);
        p2 = sdpvar(1);
        R = [-p2/r p1/r 0; 0 0 -1; -p1/r -p2/r 0];
        Z = sdpvar(n,1);

        sum = 0;
        for i = 1:n
            sum = sum + norm(R*ei(:,i) + T - Z(i)*ni(:,i), 2)^2;
        end
        constraints = [p1^2+p2^2==r^2];

        options = sdpsettings('verbose', 0, 'solver', 'gurobi');
        ans = optimize(constraints, sum, options);
        pos = [value(p1); value(p2); 0];
    else
        % assume: "equator -> origin"

    zeta_hat = analog_2_camera(eta); 

    N = size(zeta_hat,2);

    p = sdpvar(2,1);
    alpha = sdpvar(N,1);
    e = sdpvar(3,N);

    constraints = [p <= r*ones(2,1), ...
                   p >= -r*ones(2,1), ...
                   alpha >= zeros(N,1)];
    objective = 0;

    for i = 1:1:N
        constraints = [constraints, e(:,i)==zeta_hat(:,i)*alpha(i)-([-p(2)/r,0,-p(1)/r;p(1)/r,0,-p(2)/r;0,-1,0]'*xi(:,i) + [0;0;r])];
        objective = objective + e(:,i)'*e(:,i);
    end


    % ops = sdpsettings('verbose',0);
    ops = sdpsettings('verbose',0,'solver','GUROBI');
    % ops = sdpsettings('solver','mosek','verbose',2);
    diagnostics = optimize(constraints,objective,ops);
    if diagnostics.problem ~= 0
        warning('infeasible !');
    end
    pos = [value(p);0];
    end
end

% function pos = estimate_pos(eta, xi, r, type)
% assume: "equator -> origin"
% 
%     zeta_hat = analog_2_camera(eta); 
% 
%     N = size(zeta_hat,2);
% 
%     p = sdpvar(2,1);
%     alpha = sdpvar(N,1);
%     e = sdpvar(3,N);
% 
%     constraints = [p <= r*ones(2,1), ...
%                    p >= -r*ones(2,1), ...
%                    alpha >= zeros(N,1)];
%     objective = 0;
% 
%     for i = 1:1:N
%         constraints = [constraints, e(:,i)==zeta_hat(:,i)*alpha(i)-([-p(2)/r,0,-p(1)/r;p(1)/r,0,-p(2)/r;0,-1,0]'*xi(:,i) + [0;0;r])];
%         objective = objective + e(:,i)'*e(:,i);
%     end
% 
% 
%     ops = sdpsettings('verbose',0);
%     ops = sdpsettings('verbose',0,'solver','GUROBI');
%     ops = sdpsettings('solver','mosek','verbose',2);
%     diagnostics = optimize(constraints,objective,ops);
%     if diagnostics.problem ~= 0
%         warning('infeasible !');
%     end
%     pos = [value(p);0];
% end



% p = sdpvar(3,1);
% R = sdpvar(3,3);
% alpha = sdpvar(N,1);
% 
% constraints = [R == [-p(2)/r, 0, -p(1)/r;
%                       p(1)/r, 0, -p(2)/r;
%                       0,     -1, 0], ...
%                p <= r*ones(3,1), ...
%                p >= -r*ones(3,1), ...
%                p(3) == 0, ...
%                alpha >= zeros(N,1)];
% objective = 0;
% 
% for i = 1:1:N
%     % objective = objective + norm(alpha(i)*zeta_hat(:,i)-(R_inv*xi(:,i)-[0;0;r]),2);
%     objective = objective + norm(zeta_hat(:,i)*alpha(i)-(R'*xi(:,i) + [0;0;r]),2);
% end
% 
% ops = sdpsettings('verbose',0);
% % ops = sdpsettings('verbose',0,'solver','GUROBI');
% diagnostics = optimize(constraints,objective,ops);
% if diagnostics.problem ~= 0
%     warning('infeasible !');
% end
% pos = value(p);