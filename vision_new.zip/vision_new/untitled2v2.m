n = 8;
sigma = 0.01;

%generate the training data (8 points)
alpha0 = rand; alpha1 = rand;
beta0 = rand; beta1 = rand;
desired = [alpha0 alpha1 beta0 beta1];

c = rand(3,1); %center of prism
w = rand; h = 1; l = rand;
disp(w); disp(l);
v1 = [-w/2; -l/2; h/2] + c;
v2 = [w/2; -l/2; h/2] + c;
v3 = [w/2; -l/2; -h/2] + c;
v4 = [-w/2; -l/2; -h/2] + c;
v5 = [-w/2; l/2; h/2] + c;
v6 = [w/2; l/2; h/2] + c;
v7 = [w/2; l/2; -h/2] + c;
v8 = [-w/2; l/2; -h/2] + c;
V = [v1 v2 v3 v4 v5 v6 v7 v8];

ximarray = []; yimarray = [];
for i = 1:n
    Xi = V(1,i); 
    Yi = V(2,i);
    Zi = V(3,i);
    ximarray = [ximarray; (alpha1*Xi + alpha0*Zi)/Zi];
    yimarray = [yimarray; (beta1*Yi + beta0*Zi)/Zi];
end

%QP formulation of optimization problem 
x = sdpvar(30,1);
Q = getQmodel2();

A = [];
for i = 1:n
    xim = ximarray(i);
    yim = yimarray(i);
    A = blkdiag(A, [alpha1 0 alpha0-xim; 0 beta1 beta0-yim]);
end
A = [A zeros(2*n, 6)];
A = [A; zeros(1,29) 1];
b = zeros(2*n, 1);
b = [b; 1];

G = zeros(2,30);
G(1,28) = -1; G(2,29) = -1;
h = [0; 0];

constraints = [A*x == b];
constraints = constraints + [G*x <= h];
options = sdpsettings('verbose', 1, 'solver', 'gurobi');
ans = optimize(constraints, x'*Q*x, options)
opt = value(x);
clear x

%add some noise to the image coordinates
opt = opt + sigma*randn(size(opt));

%solve the resulting optimization problem
alpha0 = sdpvar(1); alpha1 = sdpvar(1);
beta0 = sdpvar(1); beta1 = sdpvar(1);
lambda = sdpvar(2,1);
v = sdpvar(17,1);

A = [];
for i = 1:n
    xim = ximarray(i);
    yim = yimarray(i);
    A = blkdiag(A, [alpha1 0 alpha0-xim; 0 beta1 beta0-yim]);
end
A = [A zeros(2*n, 6)];
A = [A; zeros(1,29) 1];
b = zeros(2*n, 1);
b = [b; 1];

kkt1 = Q*opt + A'*v + G'*lambda;
kkt2 = A*opt - b;
kkt3 = diag(lambda)*(G*opt-h);
constraints = [lambda >= 0];
objective = norm(kkt1, inf) + norm(kkt2, inf) + norm(kkt3, inf);

options = sdpsettings('verbose', 1, 'solver', 'gurobi');
options.gurobi.presolve = 0;
ans = optimize(constraints, objective, options)
disp(desired)
[value(alpha0) value(alpha1) value(beta0) value(beta1)]