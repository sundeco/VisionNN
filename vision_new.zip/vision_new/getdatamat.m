%generate the dataMat and centerMat that will be used in untitled2v2
%random dimensions and center location 
r = 3; %camera location 
camera_pos = [r; 0; 0];
camera_dir = pos_2_dir(camera_pos);
dataMat = [];
centerMat = [];

for i = 1:3000
    w = (rand+0.5);
    l = (rand+0.5);
    h = 1;
    prism = get_prism(zeros(3,1), w,l,h); 
    center = 2*rand(3,1)-1;

    img = get_vision2(camera_pos, camera_dir, center, w, l, h);
    pixls = get_corner_pixl(img); 
    if sum(sum(isnan(pixls))) ~= 0
        continue
    end
    eta = pixls/60*2;
    
    input = [eta(1,:)'; eta(2,:)'];
    output = [center; w; l];
    dataMat = [dataMat input];
    centerMat = [centerMat output];
end