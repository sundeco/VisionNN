function eta = pixl_2_analog(pixl)

% 60: # row = # col of the square image
% 1.4: side length of the square screen
eta = pixl/60*1.4;

