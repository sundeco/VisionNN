function camera = get_camera_const()

camera.f = 1;

s = 0.7; % side length of the screen

camera.cu = s; % analogue
camera.cv = s; 
camera.ku = 1;
camera.kv = 1;

camera.gamma = 0;