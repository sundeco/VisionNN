% This program is used to detect corners or points in an image using color intensity as the standard unlike usual methods of applying it on grey scale images
% Written by Rajeev Madazhy
% Graduate Student
% Department of Mechanical Engineering, LSU, Baton Rouge, LA
% Contact Information:  rmadaz1@lsu.edu

clear;
close all;
im = imread(['im1.png']);
sz=size(im);
m=sz(:,1);
n=sz(:,2);
cl=sz(:,3);
k=1;

for h=1:cl
    for i=1:m-2
        for j=1:n-2
            if im(i,j,h) <=100 & im(i+1,j,h) <=100 & im(i+2,j,h) <=100 | im(i,j,h) <=100 & im(i,j+1,h) <=100 & im(i,j+2,h) <=100 
                
            elseif im(i,j,h) <=100
                point_locator(k,1)=i;
                point_locator(k,2)=j;
                point_locator(k,3)=h;
                k=k+1;
            end
        end
    end
end
% to get the points from the the point_locator matrix
x=size(point_locator);
x1=x(:,1);
x2=x1/3;
refined_point_locator=point_locator(1:x2,1:2);
                  
figure;
imagesc(im);
colormap('gray');
hold on;
plot(refined_point_locator(:,2),refined_point_locator(:,1),'y*');




 