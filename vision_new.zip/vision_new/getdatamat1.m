%generate the dataMat and centerMat that will be used in untitled2v2
%random dimensions and center location 

w = (rand+0.5);
l = (rand+0.5);
h = 1;
center = rand(3,1)-1/2;
c = center;

v1 = [-w/2; -l/2; h/2] + c;
v2 = [w/2; -l/2; h/2] + c;
v3 = [w/2; -l/2; -h/2] + c;
v4 = [-w/2; -l/2; -h/2] + c;
v5 = [-w/2; l/2; h/2] + c;
v6 = [w/2; l/2; h/2] + c;
v7 = [w/2; l/2; -h/2] + c;
v8 = [-w/2; l/2; -h/2] + c;
V = [v1 v2 v3 v4 v5 v6 v7 v8];
Xiarray = V(1,:);
Yiarray = V(2,:);
Ziarray = V(3,:);

dataMat = [];
centerMat = [];
junk = [];

for i = 1:2000
    r = 3;
    theta = 2*pi*rand;
    prism = get_prism(center, w,l,h); 

    camera_pos = [r*cos(theta); r*sin(theta); 0]; % p
    camera_dir = pos_2_dir(camera_pos); % R(p)
    
    img = get_vision2(camera_pos, camera_dir, center, w, l, h, r);
    pixls = get_corner_pixl(img); 
    if sum(sum(isnan(pixls))) ~= 0
        continue
    end
    eta = pixls/80*3;
    eta(2,:) = 3-eta(2,:);
    junk = [junk; max(max(pixls))];
    
    input = [eta(1,:)'; eta(2,:)'];
    output = [camera_pos(1:2); r];
    dataMat = [dataMat input];
    centerMat = [centerMat output];
end