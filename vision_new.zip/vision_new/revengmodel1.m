total = [];
for iter = 1:100
clearvars -except total
load model1NN1.mat

[~, maxsize] = size(dataMat);
index = floor(maxsize*rand)+1;
ximarray = dataMat(1:points, index);
yimarray = dataMat(points+1:2*points, index);
%prediction = predict(net, dataMat(:,index)');
prediction = centerMat(:,index);
prediction = prediction';
p1 = prediction(1); 
p2 = prediction(2);
r = prediction(3);
R = [-p2/r p1/r 0; -p1/r -p2/r 0; 0 0 -1];
opt = [p1/r; p2/r; r];

%figure out values of Zic assuming we know Xi Yi Zi 
for i = 1:points
    Xi = Xiarray(i);
    Yi = Yiarray(i);
    Zi = Ziarray(i);
    Hi = [Yi -Xi 0; -Xi -Yi 0; 0 0 1];
    hi = [0; 0; Zi];
    zz = Hi*[p1/r; p2/r; r] - [0; 0; Zi];
    opt = [opt; zz(3)];
end
opt = double(opt);

%Reverse engineering: L and l are not known here
%desired = [negsxf negsyf sox soy];
% L = sdpvar(3,2);
% l = sdpvar(3,1);
aa = sdpvar(1,4);
L = [aa(1) 0; 0 aa(2); 0 0];
l = [aa(3); aa(4); 1];

Q = zeros(points+3);
q = zeros(points+3, 1);
for i = 1:points
    Xi = Xiarray(i); 
    Yi = Yiarray(i); 
    Zi = Ziarray(i);
    xim = ximarray(i);
    yim = yimarray(i);
    Hi = [Yi -Xi 0; -Xi -Yi 0; 0 0 1];
    hi = [0; 0; Zi];
    a = L*[xim; yim] + l;
    B = [Hi zeros(3, i-1) -a zeros(3, points-i)]; 
    Q = Q + B'*B;
    q = q - B'*hi;
end

G = zeros(5,3);
G(1,1) = 1; G(2,1) = -1; %p_1
G(3,2) = 1; G(4,2) = -1; %p_2
G(5,3) = -1; %r>0 constraint
G = blkdiag(G, -eye(points));
h = [1; 1; 1; 1; zeros(points+1,1)];

kkt1 = Q*opt +q;
objective = norm(kkt1, inf);

constraints = [];
options = sdpsettings('verbose', 1, 'solver', 'gurobi');
options.gurobi.TimeLimit = 30;
ans = optimize(constraints, objective, options);
%disp(value(L))
%disp(value(l))
%disp(desired)
tmp = value(aa)
total = [total; tmp];
end