function pixls = get_corner_pixl(img)

pixl1 = ceil(mean(clr_filter(img, [0.9100 0.4100 0.1700]),2));
pixl2 = ceil(mean(clr_filter(img, [1 0 0]),2));
pixl3 = ceil(mean(clr_filter(img, [0 1 0]),2));
pixl4 = ceil(mean(clr_filter(img, [0 0 1]),2));
pixl5 = ceil(mean(clr_filter(img, [0.2, 0.5, 0.8]),2));
pixl6 = ceil(mean(clr_filter(img, [0.6, 0.7, 0.4]),2));
pixl7 = ceil(mean(clr_filter(img, [0.9, 0.2, 0.4]),2));
pixl8 = ceil(mean(clr_filter(img, [0.7, 0.9, 0.5]),2));

pixls = [pixl2, pixl6, pixl7, pixl3, pixl1, pixl5, pixl8, pixl4];