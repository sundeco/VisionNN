L = sdpvar(3,2);
l = sdpvar(3,1);
lambda = sdpvar(n+5,1);
v = sdpvar(3*n,1);
n = 20;

%first determine Xiarray and opt
%compute Zics and eis in equation (68)
opt = [p1; p2; r];

Q = zeros(n+3);
for i = 1:n
    Q = blkdiag(Q, eye(3));
end

A = []; b = []; diagA = [];
for i = 1:n
    Xi = Xiarray(i);
    Yi = Yiarray(i);
    Zi = Ziarray(i);
    Hi = [Yi -Xi 0; 0 0 0; -Xi -Yi 1];
    hi = [0; Zi; 0];
    xim = ximarray(i);
    yim = yimarray(i);
    Ai = L*[xim; yim] + l;
    A = [A; Hi];
    b = [b; hi];
    diagA = blkdiag(diagA, -Ai);
end
temp = [];
for i = 1:n
    temp = blkdiag(temp, -eye(3));
end
A = [A diagA temp];

G = zeros(5,3);
G(1,1) = 1; G(2,1) = -1; %p_1
G(3,2) = 1; G(4,2) = -1; %p_2
G(5,3) = -1; %r>0 constraint
G = blkdiag(G, -eye(n));
G = [G zeros(n+5, 3*n)];
h = [1; 1; 1; 1; zeros(n+1,1)];

kkt1 = Q*opt + A'*v + G'*lambda;
kkt2 = A*opt - b;
kkt3 = diag(lambda)*(G*opt-h);
constraints = [lambda >= 0];
%objective = kkt1'*kkt1 + kkt2'*kkt2 + kkt3'*kkt3;
objective = norm(kkt1, 1) + norm(kkt2, 1) + norm(kkt3, 1);

options = sdpsettings('verbose', 1, 'solver', 'gurobi');
ans = optimize(constraints, objective, options)

disp(value(L))
disp(negsxf)
disp(negsyf)