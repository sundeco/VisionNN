function img = get_vision(camera_pos, camera_dir)

smplx = get_simplex(); 

h = figure; 
h.Position = [100 100 400 400];
set(gca,'position',[0 0 1 1],'units','normalized')

hold on
dome = Polyhedron('lb',[-10, -10],'ub', [10, 10]);
plot(dome,'color',[1,1,1], 'alpha',1, 'linestyle','none','edgecolor','black');

img_Box = [];
for i = 1:1:4
    m = world_2_analog(smplx.Box(i).V', camera_pos, camera_dir);
    img_Box = [img_Box, Polyhedron('V', m(1:2,:)');];
    % l = world_2_analog([[0;0;0],smplx.V(:,i)], camera_pos, camera_dir);
end

e12 = world_2_analog([smplx.V(:,1),smplx.V(:,2)], camera_pos, camera_dir);
e13 = world_2_analog([smplx.V(:,1),smplx.V(:,3)], camera_pos, camera_dir);
e14 = world_2_analog([smplx.V(:,1),smplx.V(:,4)], camera_pos, camera_dir);
e23 = world_2_analog([smplx.V(:,2),smplx.V(:,3)], camera_pos, camera_dir);
e24 = world_2_analog([smplx.V(:,2),smplx.V(:,4)], camera_pos, camera_dir);
e34 = world_2_analog([smplx.V(:,3),smplx.V(:,4)], camera_pos, camera_dir);

% plot(l(1,:), l(2,:), 'Linewidth', 3, 'Color', [0 0 0]); 

plot(e12(1,:), e12(2,:), 'Linewidth', 3, 'Color', [0 0 0]); 
plot(e13(1,:), e13(2,:), 'Linewidth', 3, 'Color', [0 0 0]); 
plot(e14(1,:), e14(2,:), 'Linewidth', 3, 'Color', [0 0 0]); 
plot(e23(1,:), e23(2,:), 'Linewidth', 3, 'Color', [0 0 0]);
plot(e24(1,:), e24(2,:), 'Linewidth', 3, 'Color', [0 0 0]);
plot(e34(1,:), e34(2,:), 'Linewidth', 3, 'Color', [0 0 0]);


plot(img_Box(1),'color',[0.9100 0.4100 0.1700], 'alpha',1, 'linestyle','none','edgecolor','black');
plot(img_Box(2),'color',[1,0,0], 'alpha',1, 'linestyle','none','edgecolor','black');
plot(img_Box(3),'color',[0,1,0], 'alpha',1, 'linestyle','none','edgecolor','black');
plot(img_Box(4),'color',[0,0,1], 'alpha',1, 'linestyle','none','edgecolor','black');

axis([0, 1.4, 0, 1.4])
grid off
axis off
axis square

% pause;
F = getframe(gcf);
[img, ~] = frame2im(F);
img = imresize(img, 0.1);

close(h)
