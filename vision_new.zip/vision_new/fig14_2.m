n = 20;
sigma = 0.05;

%first generate the data itself, then add some noise and optimize
r = rand+1;
p1 = rand; p2 = sqrt(1-p1^2);
sox = rand; soy = rand;
negsxf = -rand; negsyf = -rand;
R = [-p2 p1 0; -p1 -p2 0; 0 0 -1];

%store i dependencies in arrays 
Xiarray = 2*rand(n,1)-1;
Yiarray = 2*rand(n,1)-1;
Ziarray = rand(n,1);
ximarray = zeros(n,1);
yimarray = ximarray;
Zicarray = ximarray;
for i = 1:n
    Xcvec = R*[Xiarray(i); Yiarray(i); Ziarray(i)] + [0; 0; r];
    rvec = Xcvec/Xcvec(3);
    xim = (rvec(1)-sox)/negsxf;
    yim = (rvec(2)-soy)/negsyf;
    ximarray(i) = xim; 
    yimarray(i) = yim;
    Zicarray(i) = Xcvec(3);
end

%verify this part is done correctly
Xi = Xiarray(i);
Yi = Yiarray(i);
Zi = Ziarray(i);
xim = ximarray(i); 
yim = yimarray(i);
Hi = [Yi -Xi 0; -Xi -Yi 0; 0 0 1];
hi = [0; 0; Zi];
L = [negsxf 0; 0 negsyf; 0 0];
l = [sox; soy; 1];
Hi*[p1; p2; r] - hi
(L*[xim; yim] + l)*Zicarray(i)
(L*[xim; yim] + l)*Zicarray(i) + hi - Hi*[p1; p2; r]

%add noise to the data 
%Xiarray = Xiarray + sigma*randn(n,1);
%Yiarray = Yiarray + sigma*randn(n,1);
%Ziarray = Ziarray + sigma*randn(n,1);
ximarray = ximarray + sigma*randn(n,1);
yimarray = yimarray + sigma*randn(n,1);

constraints = [];
objective = 0;

e = sdpvar(3*n, 1); %stacked version of all ei's
L = [negsxf 0; 0 negsyf; 0 0];
l = [sox; soy; 1];
p1 = sdpvar(1);
p2 = sdpvar(1);
r = sdpvar(1);
Zic = sdpvar(n,1);

for i = 1:n
    Xi = Xiarray(i);
    Yi = Yiarray(i);
    Zi = Ziarray(i);
    xim = ximarray(i); 
    yim = yimarray(i);
    Hi = [Yi -Xi 0; -Xi -Yi 0; 0 0 1];
    hi = [0; 0; Zi];
    
    ei = e(3*i-2:3*i);
    constraints = constraints + [ei == (L*[xim; yim] + l)*Zic(i) + hi - Hi*[p1; p2; r]];
    objective = objective + ei'*ei;
end
constraints = constraints + [-1 <= p1 <= 1];
constraints = constraints + [-1 <= p2 <= 1];
constraints = constraints + [r >= 0];
constraints = constraints + [Zic >= 0];

options = sdpsettings('verbose', 1, 'solver', 'gurobi');
ans = optimize(constraints, objective, options)
%opt = [value(p1); value(p2); value(r); value(Zic); value(e)];
opt = [value(p1); value(p2); value(r); value(Zic)];
constraints = [];

%clear a bunch of crap
clear e
clear ei
clear p1
clear p2
clear r
clear Zic

%Reverse engineering: L and l are not known here
L = sdpvar(3,2);
l = sdpvar(3,1);

% % d1 = sdpvar(2,1); %diagonals of L
% 
Q = zeros(n+3);
q = zeros(n+3, 1);
for i = 1:n
    Xi = Xiarray(i); 
    Yi = Yiarray(i); 
    Zi = Ziarray(i);
    xim = ximarray(i);
    yim = yimarray(i);
    Hi = [Yi -Xi 0; -Xi -Yi 0; 0 0 1];
    hi = [0; 0; Zi];
    a = L*[xim; yim] + l;
    B = [Hi zeros(3, i-1) -a zeros(3, n-i)]; 
    Q = Q + B'*B;
    q = q - B'*hi;
end

G = zeros(5,3);
G(1,1) = 1; G(2,1) = -1; %p_1
G(3,2) = 1; G(4,2) = -1; %p_2
G(5,3) = -1; %r>0 constraint
G = blkdiag(G, -eye(n));
h = [1; 1; 1; 1; zeros(n+1,1)];

kkt1 = Q*opt +q;
objective = norm(kkt1, inf);

options = sdpsettings('verbose', 1, 'solver', 'gurobi', 'usex0', 1);
ans = optimize(constraints, objective, options)

disp(value(L))
disp(negsxf)
disp(negsyf)