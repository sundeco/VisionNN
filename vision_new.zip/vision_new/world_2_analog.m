function m = world_2_analog(Mw, camera_pos, camera_dir)

m = [];
for i = 1:1:size(Mw,2)
    m = [m, camera_2_analog(world_2_camera(Mw(:,i), camera_pos, camera_dir))];
end