%generate training data for a neural network
%input is 8 vertices of the prism (2D image) 
%output is 3D center of the prism 

dataMatrix = [];
centers = [];
for i = -1:0.1:1
    for j = -1:0.1:1
        for k = -1:0.1:1
            if rand>0.1
                continue
            end
            %take ten percent of 0.1 spacing points 
            theta = pi/3;
            camera_pos = [r*cos(theta); r*sin(theta); 0]; % p
            camera_dir = pos_2_dir(camera_pos); % R(p)
            img = get_vision2(camera_pos, camera_dir, [i; j; k]);
            
            pixls = get_corner_pixl(img); 
            eta = pixls/60*2;
            dataMatrix = [dataMatrix; eta(:)'];
            centers = [centers; [i j k]];
        end
    end
end