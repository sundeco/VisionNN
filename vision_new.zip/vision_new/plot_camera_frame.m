function plot_camera_frame(pos, dir)

plot_arrow(pos, pos+dir(:,1),'$x_c$');
plot_arrow(pos, pos+dir(:,2),'$y_c$');
plot_arrow(pos, pos+dir(:,3),'$z_c$');