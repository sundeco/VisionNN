function prism = get_prism(offset, w, l, h)
    v1 = [-w/2; -l/2; h/2] + offset;
    v2 = [w/2; -l/2; h/2] + offset;
    v3 = [w/2; -l/2; -h/2] + offset;
    v4 = [-w/2; -l/2; -h/2] + offset;
    v5 = [-w/2; l/2; h/2] + offset;
    v6 = [w/2; l/2; h/2] + offset;
    v7 = [w/2; l/2; -h/2] + offset;
    v8 = [-w/2; l/2; -h/2] + offset;
    
    prism.V = [v1, v2, v3, v4, v5, v6, v7, v8];
    prism.V = prism.V
    
    box = Polyhedron('lb', -0.1*ones(3,1), 'ub', 0.1*ones(3,1));
    box1 = v1+box; 
    box2 = v2+box; 
    box3 = v3+box; 
    box4 = v4+box; 
    box5 = v5+box; 
    box6 = v6+box; 
    box7 = v7+box; 
    box8 = v8+box; 
   
    prism.Box = [box1; box2; box3; box4; box5; box6; box7; box8];
end