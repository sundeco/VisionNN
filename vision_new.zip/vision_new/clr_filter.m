function pixl = clr_filter(img, clr)

clr_3 = zeros(1,1,3); 
clr_3(1,1,1) = clr(1)*255;   
clr_3(1,1,2) = clr(2)*255;
clr_3(1,1,3) = clr(3)*255; 

diff = double(img) - clr_3; 
error = vecnorm(diff,2,3);

[row,col] = find(error<20); 

pixl = [col'; row']; 