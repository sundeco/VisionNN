function zeta = world_2_camera(xi, camera_pos, camera_dir)
% extrinsic map

for i = 1:1:3
    camera_dir(:,i) = camera_dir(:,i)/norm(camera_dir(:,i),2); 
end

zeta = camera_dir\(xi - camera_pos); 