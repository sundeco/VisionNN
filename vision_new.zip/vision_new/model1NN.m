%neural network for 9.2.1
%input: n 2D image points
%output: location of the camera p1 p2 r
sox = 0.4; soy = 0.2;
negsxf = -0.3; negsyf = -0.5;
points = 8;
dataPoints = 1000;

w = 0.5808;
l = 0.518;
h = 1;
center = [0.296897652303191;0.0479984510607105;0.466950166769187];
c = center;

v1 = [-w/2; -l/2; h/2] + c;
v2 = [w/2; -l/2; h/2] + c;
v3 = [w/2; -l/2; -h/2] + c;
v4 = [-w/2; -l/2; -h/2] + c;
v5 = [-w/2; l/2; h/2] + c;
v6 = [w/2; l/2; h/2] + c;
v7 = [w/2; l/2; -h/2] + c;
v8 = [-w/2; l/2; -h/2] + c;
V = [v1 v2 v3 v4 v5 v6 v7 v8];
Xiarray = V(1,:);
Yiarray = V(2,:);
Ziarray = V(3,:);
% Xiarray = rand(points,1);
% Yiarray = rand(points,1);
% Ziarray = rand(points,1);
dataMat = []; centerMat = [];

for j = 1:dataPoints
%     p1 = 3*rand;
%     p2 = 3*rand;
    tobreak = false;
    r = 3;
    theta = 2*pi*rand;
    p1 = r*cos(theta);
    p2 = r*sin(theta);
    
    camera_pos = [p1; p2; 0]; % p
    R = pos_2_dir(camera_pos); % R(p)
    
    ximarray = []; yimarray = [];
   
    for i = 1:points
        Xcvec = R*[Xiarray(i); Yiarray(i); Ziarray(i)] + [0; 0; r];
        rvec = Xcvec/Xcvec(3);
        xim = (rvec(1)-sox)/negsxf;
        yim = (rvec(2)-soy)/negsyf;
        if xim<0 || xim>3 || yim<0 || yim>3
            tobreak = true;
            break;
        end
        ximarray = [ximarray; xim];
        yimarray = [yimarray; yim];
    end
    if tobreak
        continue;
    end
    input = [ximarray; yimarray];
    output = [p1; p2; r];
    dataMat = [dataMat input];
    centerMat = [centerMat output];
end

layers = [
    featureInputLayer(2*points,'Name','input')
     fullyConnectedLayer(2*points, 'Name', 'fc16')
     leakyReluLayer
     fullyConnectedLayer(10, 'Name', 'fc10')
     leakyReluLayer
    fullyConnectedLayer(3, 'Name', 'fc')
    regressionLayer]
options = trainingOptions('sgdm', ...
    'MaxEpochs', 5000, ...
    'InitialLearnRate',0.002, ...
    'Verbose',false, ...
    'Plots','training-progress');
[net, info] = trainNetwork(dataMat', centerMat', layers, options)